const btnAcertos = document.getElementById('btn-acertos');
const resFim = document.getElementById('res-fim');

btnAcertos.addEventListener('click', calcularAcertos);

function calcularAcertos() {
  const perguntas = document.querySelectorAll('.caixa-entrada');

  let acertos = 0;

  perguntas.forEach((pergunta) => {
    const respostaCorreta = pergunta.querySelector('select').value;
    const perguntaId = pergunta.querySelector('select').name;

    switch (perguntaId) {
      case 'herois':
        if (respostaCorreta === 'b)') {
          acertos++;
        }
        break;
      case 'Desenho':
        if (respostaCorreta === '3)') {
          acertos++;
        }
        break;
      case 'Nome':
        if (respostaCorreta === '4)') {
          acertos++;
        }
        break;
      case 'qual':
        if (respostaCorreta === '2)') {
          acertos++;
        }
        break;
      case 'jovem':
        if (respostaCorreta === '3)') {
          acertos++;
        }
        break;
      case 'crianças':
        if (respostaCorreta === '2)') {
          acertos++;
        }
        break;
      case 'amigo':
        if (respostaCorreta === '3)') {
          acertos++;
        }
        break;
      case 'cão':
        if (respostaCorreta === '1)') {
          acertos++;
        }
        break;
      case 'vilão':
        if (respostaCorreta === '1)') {
          acertos++;
        }
        break;
      case 'canina':
        if (respostaCorreta === '1)') {
          acertos++;
        }
        break;
      case 'panda':
        if (respostaCorreta === '1)') {
          acertos++;
        }
        break;
      default:
        break;
    }
  });

  resFim.value = acertos;
}
